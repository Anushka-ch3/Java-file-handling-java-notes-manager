import java.io.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Javafilehandling {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String file1 = "JavaFile1.txt";
        String text1 = """
                Java is an object-oriented programming language.
                It supports encapsulation, inheritance, and polymorphism.
                File handling in Java allows for efficient reading and searching of text.
                Keep learning and mastering Java!
                """;

        createNote(file1, text1);

        System.out.println("\n--- Contents of JavaFile1.txt ---");
        displayNote(file1);

        String file2 = "JavaFile2.txt";
        System.out.println("\nEnter first line for JavaFile2.txt:");
        String userLine = sc.nextLine();

        createNote(file2, userLine + "\n");

        copyContent(file1, file2);

        System.out.println("\n--- Analyzing JavaFile1.txt ---");
        analyzeNote(file1, "polymorphism");

        System.out.println("\n--- Analyzing JavaFile2.txt ---");
        analyzeNote(file2, "polymorphism");

        sc.close();
    }

    public static void createNote(String filename, String content) {
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write(content);
            System.out.println("Note saved to " + filename);
        } catch (IOException e) {
            System.out.println("Error writing to " + filename + ": " + e.getMessage());
        }
    }

    public static void displayNote(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null)
                System.out.println(line);
        } catch (IOException e) {
            System.out.println("Error reading " + filename + ": " + e.getMessage());
        }
    }

    public static void copyContent(String fromFile, String toFile) {
        try (
            BufferedReader br = new BufferedReader(new FileReader(fromFile));
            FileWriter fw = new FileWriter(toFile, true)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                fw.write(line + "\n");
            }
            System.out.println("Contents of " + fromFile + " appended to " + toFile);
        } catch (IOException e) {
            System.out.println("Error copying content: " + e.getMessage());
        }
    }

    public static void analyzeNote(String filename, String searchWord) {
        int charCount = 0;
        int wordCount = 0;
        int lineCount = 0;
        int searchCount = 0;
        int firstOccurrenceLine = -1;

        Pattern wordPattern = Pattern.compile("\\b" + Pattern.quote(searchWord) + "\\b", Pattern.CASE_INSENSITIVE);

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int currentLine = 1;
            while ((line = br.readLine()) != null) {
                lineCount++;
                charCount += line.length();

                String[] words = line.trim().split("\\s+");
                for (String word : words) {
                    if (!word.isEmpty()) {
                        wordCount++;
                    }
                }

                Matcher matcher = wordPattern.matcher(line);
                int lineMatches = 0;
                while (matcher.find()) {
                    lineMatches++;
                }

                if (lineMatches > 0 && firstOccurrenceLine == -1) {
                    firstOccurrenceLine = currentLine;
                }

                searchCount += lineMatches;
                currentLine++;
            }

            System.out.println("\n--- Analysis of " + filename + " ---");
            System.out.println("Total characters: " + charCount);
            System.out.println("Total lines: " + lineCount);
            System.out.println("Total words: " + wordCount);
            if (searchCount > 0) {
                System.out.println("Word \"" + searchWord + "\" found at line number: " + firstOccurrenceLine);
                System.out.println("Total occurrences: " + searchCount);
            } else {
                System.out.println("Word \"" + searchWord + "\" not found.");
            }

        } catch (IOException e) {
            System.out.println("Error analyzing file: " + e.getMessage());
        }
    }
}