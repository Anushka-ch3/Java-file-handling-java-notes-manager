/**
 * 
 */
/**
 * 
 */
module javanotesmanager {
}